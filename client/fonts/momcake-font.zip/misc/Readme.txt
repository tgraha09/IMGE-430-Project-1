LICENSE

This font is free for personal use.

For commercial use, donate via Paypal to : rvn19@yahoo.com

---------------------------------------------------------------------

Need lowercase too?

Get PRO version here https://www.behance.net/gallery/97358703/MOMCAKE-Typeface

- Uppercase & lowercase
- 4 Weights ( thin, regular, medium, bold )
- Punctuation & Symbol
- Multilingual
- Alternates

----------------------------------------------------------------------

Copyright is still with us. You are not allowed to :
- Resell / redistribute the font
- Edit / modify the font to resell / redistribute

----------------------------------------------------------------------

Rivian Art - rivianart.blogspot.com